class HL7Handler:
    @staticmethod
    def encode(hl7_message: str) -> str:
        return hl7_message  # For now, just string

    @staticmethod
    def decode(payload: str) -> str:
        return payload
