# MQTT connect/publish/subscribe wrapper

import paho.mqtt.client as mqtt
import threading

class MQTTManager:
    def __init__(self, client_id, broker='localhost', port=1883):
        self.client = mqtt.Client(client_id=client_id)
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.subscriptions = {}
        self.client.connect(broker, port, 60)
        self.thread = threading.Thread(target=self.client.loop_forever)
        self.thread.daemon = True
        self.thread.start()

    def on_connect(self, client, userdata, flags, rc):
        print(f"Connected to MQTT broker with result code {rc}")

    def on_message(self, client, userdata, msg):
        topic = msg.topic
        if topic in self.subscriptions:
            self.subscriptions[topic](msg)

    def subscribe(self, topic, callback):
        self.subscriptions[topic] = callback
        self.client.subscribe(topic)

    def publish(self, topic, message):
        self.client.publish(topic, message)